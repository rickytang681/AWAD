<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    Welcome to YLLoo’s Web Application.
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                    <div class="btn btn-success btn-lg">
                        You have Admin Access
                    </div>
                    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAuthor')): ?>
                    <div class="btn btn-primary btn-lg">
                        You have Author Access
                    </div>
                    <?php else: ?>
                    <div class="btn btn-info btn-lg">
                        You have User Access
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\practical6.1-Copy\resources\views/home.blade.php ENDPATH**/ ?>