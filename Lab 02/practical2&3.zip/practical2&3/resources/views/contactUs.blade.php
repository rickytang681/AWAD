<x-header data="Contact Us" />
<h1>Contact us<h1>
<a href="/home">Home Page </a><br>
<a href="/about">About Us </a>