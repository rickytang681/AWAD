<x-header data="About Us" />
<h1>About us<h1>
<a href="/home">Home Page </a><br>
<a href="/contact">Contact Us </a>