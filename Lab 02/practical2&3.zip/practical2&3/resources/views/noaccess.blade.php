<x-header data="No Access" />
<h1>No Access<h1>
<a href="/home/?age=30"> Age > 18 </a><br>