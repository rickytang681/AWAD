<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['data' => 'User']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php if($username=="Ricky"): ?>
<h2> Hello <?php echo e($username); ?> </h2>
<?php elseif($username=="Peter"): ?>
<h2> Hi <?php echo e($username); ?> </h2>
<?php elseif($username=="Ali"): ?>
<h2> Bonjour, <?php echo e($username); ?> </h2>
<?php else: ?>
<h2> Unknown User </h2>
<?php endif; ?>
<br><br>


<?php echo $__env->make('userInner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br><br>


<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1> <?php echo e($user); ?> </h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script>
    var data=<?php echo json_encode($users, 15, 512) ?>;
    console.warn(data);
</script>

<!- Cross-site request forgery (CSRF) ->

<?php echo csrf_field(); ?><?php /**PATH C:\Users\PC\practical2\resources\views/user01.blade.php ENDPATH**/ ?>