<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['data' => 'User']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php if($username=="Ricky"): ?>
<h2> Hello <?php echo e($username); ?> </h2>
<?php elseif($username=="Peter"): ?>
<h2> Hi <?php echo e($username); ?> </h2>
<?php elseif($username=="Ali"): ?>
<h2> Bonjour, <?php echo e($username); ?> </h2>
<?php elseif($username=="ricky"): ?>
<h2> 您好, <?php echo e($username); ?> </h2>
<?php else: ?>
<h2> Unknown User </h2>
<?php endif; ?>
<br><br>

<!- Cross-site request forgery (CSRF) ->

<?php echo csrf_field(); ?><?php /**PATH C:\Users\PC\practical2\resources\views/user.blade.php ENDPATH**/ ?>