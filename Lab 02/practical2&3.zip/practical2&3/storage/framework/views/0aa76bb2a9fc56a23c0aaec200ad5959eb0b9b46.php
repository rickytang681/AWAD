<div>
    <h1> <?php echo e($headerTitle); ?> Header Component </h1>
    <!-- It is never too late to be what you might have been. - George Eliot -->
</div><?php /**PATH C:\Users\PC\practical2\resources\views/components/header.blade.php ENDPATH**/ ?>