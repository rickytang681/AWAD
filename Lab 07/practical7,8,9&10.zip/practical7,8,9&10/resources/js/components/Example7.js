import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Table, Button, Modal, ModalHeader, ModalBody, ModalFooter, FormGroup, Label, Input } from 'reactstrap';
import axios from 'axios';
export default class Example extends Component {
    constructor() {
        super()
        this.state = {
            posts: [], //response of API into post state
            newPostModal: false,
            updatePostModal: false,
            newPostData: { title: "", content: "", user_id: "" },
            updatePostData: { id:"", title: "", content:"", user_id:"" },
            loginModal: false,
            loginData: { email: "", password: ""},
            loginResponseData:[]            
        }
    }
   
    //sessionStorage.setItem('token', token); var token = sessionStorage.getItem('token');
    login() {        
        axios.post('http://127.0.0.1:8000/api/auth/login',
        this.state.loginData).then((response) => {
            let { loginResponseData } = this.state
            this.setState({
                loginResponseData: response.data,
                loginModal: false,
                loginData: { email: "", password: ""}                
            })            
            this.loadPost()
            console.warn(response.data);
        })
    }
    toggleloginModal() {
        this.setState({ loginModal: !this.state.loginModal })
    }
   
 
    loadPost() {
        if (!this.state.loginResponseData.access_token=="")
        {
            axios.post('http://127.0.0.1:8000/api/auth/index', {}, {
             headers: {'Authorization':
                `Bearer ${this.state.loginResponseData.access_token}`}
            }).then((response) => {                
            this.setState({
                    posts: response.data
                })
            })
        }
    }
 
    addPost() {
        axios.post('http://127.0.0.1:8000/api/auth/store',
        this.state.newPostData, {
            headers: {
                'Authorization': `Bearer ${this.state.loginResponseData.access_token}`
            }
        }).then((response) => {
            let { posts } = this.state
            this.loadPost()
            this.setState({
                posts,
                newPostModal: false,
                newPostData: { title: "", content: "", user_id: "" },
 
            })
        })
    }
 
   
    componentWillMount() {        
        this.loadPost();        
    }
    toggleNewPostModal() {
        this.setState({ newPostModal: !this.state.newPostModal })
       
    }
 
 
    callUpdatePost(id, title, content, user_id) {
        this.setState({
            updatePostData: { id, title, content, user_id },
            updatePostModal: !this.state.updatePostModal
        })
    }
   
    updatePost() {
        let { id, title, content, user_id } = this.state.updatePostData
        axios.put('http://127.0.0.1:8000/api/auth/update/' + this.state.updatePostData.id, {
            title, content, user_id},
            {       headers: {
                    'Authorization': `Bearer ${this.state.loginResponseData.access_token}`
                }
            }).then((response) => {
            this.loadPost()
            this.setState({ //after execution, set all states to false
                updatePostModal: false,
                updatePostData: { id: "", title: "", content: "", user_id: "" }
            })
        })
    }
    deletePost(id) {
       
        if (confirm("Do you want delete this Post?"))
        {
        axios.delete('http://127.0.0.1:8000/api/post/' + id, { },
        {
            headers: {
                'Authorization': `Bearer ${this.state.loginResponseData.access_token}`
            }
        }).then((response) => {
            this.loadPost()            
        })
    }
    }
    toggleUpdatePostModal() {
        this.setState({
            updatePostModal: !this.state.updatePostModal
        })
    }
    render() {
        let posts = this.state.posts.map((post) => {
            return (
                <tr key={post.id}>
                    <td>{post.id}</td>
                    <td>{post.title}</td>
                    <td>{post.content}</td>
                    <td>{post.user_id}</td>
                    <td>
                        <Button color="success" size="sm" className="mr-2"
                            onClick={this.callUpdatePost.bind(this,post.id, post.title, post.content, post.user_id)}>
                            Edit </Button>
                        <Button color="danger" size="sm" className="mr-2"  onClick={this.deletePost.bind(this,post.id)}> Delete </Button>
                    </td>
                </tr>
            )
        })
        return (
            <div className="container">
                <Button color="primary" onClick={this.toggleloginModal.bind(this)}>Login</Button>
                {"      "}
                <Button color="primary" onClick={this.toggleNewPostModal.bind(this)}>Add Post</Button>
                <Modal isOpen={this.state.newPostModal} toggle={this.toggleNewPostModal.bind(this)}>
                    <ModalHeader toggle={this.toggleNewPostModal.bind(this)}> Add New Post
                    </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <Label for="title">Title</Label>
                            <Input
                                id="title"
                                value={this.state.newPostData.title}
                                onChange={(e) => {
                                    let { newPostData } = this.state
                                    newPostData.title = e.target.value
                                    this.setState({ newPostData })
                                }}
                            ></Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="content">Content</Label>
                            <Input
                                id="content"
                                value={this.state.newPostData.content}
                                onChange={(e) => {
                                    let { newPostData } = this.state
                                    newPostData.content = e.target.value
                                    this.setState({ newPostData })
                                }}
                            ></Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="user_id">User ID</Label>
                            <Input
                                id="user_id"
                                value={this.state.newPostData.user_id}
                                onChange={(e) => {
                                    let { newPostData } = this.state
                                    newPostData.user_id = e.target.value
                                    this.setState({ newPostData })
                                }}
                            ></Input>
                        </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.addPost.bind(this)}> Add Post </Button>{' '}
                        <Button color="secondary" onClick={this.toggleNewPostModal.bind(this)}> Cancel </Button>
                    </ModalFooter>
                </Modal>
             
                <Modal isOpen={this.state.updatePostModal} toggle={this.toggleUpdatePostModal.bind(this)}>
                    <ModalHeader toggle={this.toggleUpdatePostModal.bind(this)}>Upadte Post
                    </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <Label for="title">Title</Label>
                            <Input
                                id="title"
                                value={this.state.updatePostData.title}
                                onChange={(e) => {
                                    let { updatePostData } = this.state
                                    updatePostData.title = e.target.value
                                    this.setState({ updatePostData })
                                }}
                            ></Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="content">Content</Label>
                            <Input
                                id="content"
                                value={this.state.updatePostData.content}
                                onChange={(e) => {
                                    let { updatePostData } = this.state
                                    updatePostData.content = e.target.value
                                    this.setState({ updatePostData })
                                }}
                            ></Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="user_id">User ID</Label>
                            <Input
                                id="user_id"
                                value={this.state.updatePostData.user_id}
                                onChange={(e) => {
                                    let { updatePostData } = this.state
                                    updatePostData.user_id = e.target.value
                                    this.setState({ updatePostData })
                                }}
                            ></Input>
                        </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.updatePost.bind(this)}> Edit Post </Button>{' '}
                        <Button color="secondary" onClick={this.toggleUpdatePostModal.bind(this)}> Cancel </Button>
                    </ModalFooter>
                </Modal>
 
 
                <Modal isOpen={this.state.loginModal} toggle={this.toggleloginModal.bind(this)}>
                    <ModalHeader toggle={this.toggleloginModal.bind(this)}> Login
                    </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <Label for="email">Email</Label>
                            <Input
                                id="email"
                                value={this.state.loginData.email}
                                onChange={(e) => {
                                    let { loginData } = this.state
                                    loginData.email = e.target.value
                                    this.setState({ loginData })
                                }}
                            ></Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="password">Password</Label>
                            <Input
                                id="password"
                                type="password"
                                value={this.state.loginData.password}
                                onChange={(e) => {
                                    let { loginData } = this.state
                                    loginData.password = e.target.value
                                    this.setState({ loginData })
                                }}
                            ></Input>
                        </FormGroup>                      
                   
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.login.bind(this)}> Login </Button>{'    '}
                        <Button color="secondary" onClick={this.toggleloginModal.bind(this)}> Cancel </Button>
                    </ModalFooter>
                </Modal>
                <Table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Content</th>
                            <th>User id</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {posts}
                    </tbody>
 
                </Table>
            </div>
        );
    }
}
 
if (document.getElementById('example')) {
    ReactDOM.render(<Example />, document.getElementById('example'));
}