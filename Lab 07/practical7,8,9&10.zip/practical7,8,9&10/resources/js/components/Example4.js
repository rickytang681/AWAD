// Import React and Component from the React library
import React, { Component } from 'react';
// Import ReactDOM to render the component into the DOM
import ReactDOM from 'react-dom';
// Import Bootstrap components from Reactstrap
import { Table, Button, Modal, ModalHeader, ModalBody, ModalFooter, FormGroup, Label, Input } from 'reactstrap';
// Import Axios for making HTTP requests
import axios from 'axios';

// Define the Example component class extending React.Component
export default class Example extends Component {
    constructor() {
        super(); // Call the parent constructor

        // Initialize component state with empty posts array, closed modal flag, and empty new post data object
        this.state = {
            posts: [],
            newPostModal: false,
            newPostData: { title: "", content: "", user_id: "" }
        };
    }

    // Function to load posts from the API endpoint
    loadPost() {
        axios.get('http://127.0.0.1:8000/api/posts')
            .then((response) => {
                // Update state with retrieved posts
                this.setState({ 
                    posts: response.data 
                });
            });
    }

    // Function to add a new post
    addPost() {
        // Send POST request to create a new post with data from newPostData
        axios.post('http://127.0.0.1:8000/api/post', this.state.newPostData).then((response) => {
                // Update state again to reload posts and clear new post data
                let { posts } = this.state;
                this.loadPost();
                this.setState({
                    posts,
                    newPostModal: false,
                    newPostData: { title: "", content: "", user_id: "" }
                });
            });
    }

    // Lifecycle method called before rendering, used to fetch initial data
    componentWillMount() {
        this.loadPost();
    }

    // Function to toggle the visibility of the "Add Post" modal
    toggleNewPostModal() {
        this.setState({ newPostModal: !this.state.newPostModal }); // Flip the newPostModal state
    }

    // Render function that defines the component's UI
    render() {
        // Map over posts array and create table rows for each post
        let posts = this.state.posts.map((post) => {
            return (
                <tr key={post.id}>
                    <td>{post.id}</td>
                    <td>{post.title}</td>
                    <td>{post.content}</td>
                    <td>
                        <Button color="success" size="sm" className="mr-2"> Edit </Button>
                        <Button color="danger" size="sm" className="mr-2"> Delete </Button>
                    </td>
                </tr>
            );
        });

        // Render the component with JSX elements
        return (
            <div className="container">
                <Button color="primary" onClick={this.toggleNewPostModal.bind(this)}>Add Post</Button>
                <Modal isOpen={this.state.newPostModal} toggle={this.toggleNewPostModal.bind(this)}>
                    <ModalHeader toggle={this.toggleNewPostModal.bind(this)}> Add New Post </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <Label for="title">Title</Label>
                            <Input
                                id="title"
                                value={this.state.newPostData.title}
                                onChange={(e) => {
                                    let { newPostData } = this.state;
                                    newPostData.title = e.target.value;
                                    this.setState({ newPostData });
                                }}
                            />
                        </FormGroup>
                        <FormGroup>
                            <Label for="content">Content</Label>
                            <Input
                                id="content"
                                value={this.state.newPostData.content}
                                onChange={(e) => {
                                    let { newPostData } = this.state;
                                    newPostData.content = e.target.value;
                                    this.setState({ newPostData });
                                }}
                            />
                        </FormGroup>
                        <FormGroup>
                            <Label for="user_id">User ID</Label>
                            <Input
                                id="user_id"
                                value={this.state.newPostData.user_id}
                                onChange={(e) => {
                                    let { newPostData } = this.state;
                                    newPostData.user_id = e.target.value;
                                    this.setState({ newPostData });
                                }}
                            />
                        </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.addPost.bind(this)}> Add Post </Button>{' '}
                        <Button color="secondary" onClick={this.toggleNewPostModal.bind(this)}> Cancel </Button>
                    </ModalFooter>
                </Modal>
                <Table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Content</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* Render table body with mapped posts */}
                        {posts}
                    </tbody>
                </Table>
            </div>
        );
    }
}

// Check if element with id 'p4' exists and render the component there
//id need same id in  welcome.blade.php
if (document.getElementById('p4')) {
    ReactDOM.render(<Example />, document.getElementById('p4'));
}

