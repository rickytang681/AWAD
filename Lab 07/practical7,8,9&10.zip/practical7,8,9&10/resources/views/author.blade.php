@extends('layouts.auth')
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>
                    <div class="card-body">
                        Hi there, awesome author for this site!
                    </div>
                    <div class="d-flex justify-content-end">
                        <a href="logout" class="btn btn-light">LOGOUT</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
