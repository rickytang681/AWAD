<?php
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Validator;
use App\Models\Post;
use JWTFactory;
use JWTAuth;
 
class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'register']]);
    }
    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        } //$token = JWTAuth::attempt($validator->validated());
        if (!$token = auth()->attempt($validator->validated())) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        return $this->createNewToken($token);
    }
    /**
     * Register a User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|between:2,100',
            'email' => 'required|string|email|max:100|unique:users',
            'password' => 'required|string|confirmed|min:6',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors()->toJson(), 400);
        }
        $user = User::create(
            array_merge(
                $validator->validated(),
                ['password' => bcrypt($request->password)]
            )
        );
        return response()->json([
            'message' => 'User successfully registered',
            'user' => $user
        ], 201);
    }
    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();
        return response()->json(['message' => 'User successfully signed out']);
    }
    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {                               //JWTAuth::refresh();
        return $this->createNewToken(auth()->refresh());
    }
    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function userProfile()
    {
        return response()->json(auth()->user());
    }
 
 
    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function createNewToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            //JWTFactory::getTTL();
            'expires_in' => auth()->factory()->getTTL() * 60, // TTL: time to live
            'user' => auth()->user()
        ]);
    }
 
    public function index()
    {
        $authenticated = Auth::check();
        \Log::info("User is authenticated: " . ($authenticated ? 'Yes' : 'No'));
 
        if ($authenticated) {
            return response()->json(Post::all()); // The user is logged in...
        } else
            return response()->json(['error' => 'Unauthorized'], 401);
    }
 
    public function store(Request $request)
    {
        $authenticated = Auth::check();
        \Log::info("User is authenticated: " . ($authenticated ? 'Yes' : 'No'));
 
        if ($authenticated) {
            return Post::create($request->all());
        } else
            return response()->json(['error' => 'Unauthorized'], 401);
 
    }
 
    public function update(Request $request, $id)
    {
        $authenticated = Auth::check();
        if ($authenticated) {
        $post=Post::findOrFail($id);
        $post->update($request->all());
        return response()->json($post); // The user is logged in...
        }
        else
        return response()->json(['error' => 'Unauthorized'], 401);
 
    }
 
    public function destroy($id)
    {$authenticated = Auth::check();
        if ($authenticated) {
        $post=Post::findOrFail($id);
        $post->delete();
        return response()->json("204"); // The user is logged in...
 
        }
        else
        return response()->json(['error' => 'Unauthorized'], 401);
 
    }
}