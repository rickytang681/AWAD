<div>
    <h1>Header Component</h1>
</div>