<!-- Action="/route" -->
<form action="/updateUsers" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
    <input type="text" name="name" value="<?php echo e($data['name']); ?>"> <br> <br>
    <input type="text" name="email" value="<?php echo e($data['email']); ?>"> <br> <br>
    <button type = "submit"> Update User </button>
</form><?php /**PATH C:\Users\PC\practical3\resources\views/updateUserPage.blade.php ENDPATH**/ ?>