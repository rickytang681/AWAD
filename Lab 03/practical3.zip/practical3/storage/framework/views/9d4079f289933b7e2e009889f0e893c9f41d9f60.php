<h1> User Login Header Component</h1>
<?php echo e($errors); ?>

<form action="/login" method="post">
<?php echo csrf_field(); ?>
<input type="text" name="email" placeholder="Enter Email"><br>
<input type="password" name="password" placeholder="Enter Password"><br>
<input type="hidden" name="is_admin" value="0"><br>
<button type="submit">Login</button>
</form>
<?php /**PATH C:\Users\PC\practical3\resources\views/login.blade.php ENDPATH**/ ?>