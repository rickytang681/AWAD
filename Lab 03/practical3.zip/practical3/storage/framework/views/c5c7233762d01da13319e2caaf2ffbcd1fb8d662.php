<?php if(session('user')): ?>
<h3 style="color: green">Hi, <?php echo e(session('user')); ?> you are now a registered user</h3>
<?php endif; ?>
<form action="/signUp" method="post">
<?php echo csrf_field(); ?>
<input type="text" name="name" placeholder="Enter user name"><br>
<span style="color: red" > <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span><br>
<input type="text" name="email" placeholder="Enter Email"><br>
<span style="color: red" > <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span><br>
<input type="password" name="password" placeholder="Enter Password"><br>
<span style="color: red" > <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span><br>
<input type="password" name="confirm_password" placeholder="Enter Match Password"><br>
<span style="color: red" > <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span><br>
<input type="hidden" name="is_admin" value="0"><br>
<button type="submit">Add new user</button><br><br>
</form>
<a href="/home">Home Page </a><br>
<a href="/login">Login </a><br><br><?php /**PATH C:\Users\PC\practical3\resources\views/signUp.blade.php ENDPATH**/ ?>