<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => ['data' => 'UserController']]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => 'UserController']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<h2>This is the list of Users. </h2>

<table border='1'>
    <tr>
        <td>id</td>
        <td>name</td>
        <td>email</td>
        <td>Operation</td>
        <td>Operation</td>
    </tr>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user['id']); ?></td>
        <td><?php echo e($user['name']); ?></td>
        <td><?php echo e($user['email']); ?></td>
        <td><a href =<?php echo e("deleteUser/".$user['id']); ?>>Delete</a></td>
        <td><a href =<?php echo e("updateUserNewData/".$user['id']); ?>>Update</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<style>
    .w-5{
        display: none
    }
</style>

<span>
    <?php echo e($users->links()); ?>

</span>
<?php /**PATH C:\Users\PC\Desktop\ADVANCED WEB APPLICATION DEVELOPMENT\practical3\resources\views/userInner.blade.php ENDPATH**/ ?>