<div>
    <h1>Header Component</h1>
</div><?php /**PATH C:\Users\PC\practical3\resources\views/components/header.blade.php ENDPATH**/ ?>